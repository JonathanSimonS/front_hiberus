import { mostrar_mapa } from './mapa.js';

window.addEventListener("load",init);

async function init() {
    let url = "https://www.zaragoza.es/sede/servicio/urbanismo-infraestructuras/equipamiento/aparcamiento-bicicleta.json";
    await anadirAparcamientos(url);

    let inputUsuario = document.getElementById("ubicacion");
    inputUsuario.addEventListener("keyup", mostrarSegunSeleccion);
}

// función para recibir insertar los aparcamientos en los div
async function anadirAparcamientos(url) {

    let aparcamientos = await solicitarAparcamientos(url);
    var divPadre = document.querySelector(".container_aparcamientos");
    let contador = 0;

    //aparcamientos.length
    for(let i=0;i<10;i++){
        contador++;
        let id = "mapa"+contador;

        let lat =  aparcamientos[i].geometry.coordinates[1];
        let lng =  aparcamientos[i].geometry.coordinates[0];

        var nodo = nuevoElemento(aparcamientos[i],id);
        
        mostrar_mapa(lat, lng, id, aparcamientos[i].title);

        divPadre.appendChild(nodo);

    }
}

// función para recibir los aparcamientos
async function solicitarAparcamientos(url) {
    try {
        let respuesta = await fetch(url);       
        let datos = await respuesta.json();
        return datos.result;
    } catch (err) {
        console.error(err);
    }
}

async  function mostrarSegunSeleccion() {
    let url = "https://www.zaragoza.es/sede/servicio/urbanismo-infraestructuras/equipamiento/aparcamiento-bicicleta.json";
    let aparcamientos = await solicitarAparcamientos(url);
    
    var divPadre = document.querySelector(".container_aparcamientos");
    
    // borro los que haya mostrados
    while (divPadre.firstChild) {
            divPadre.removeChild(divPadre.firstChild);
        }

    let contador = 0;

    
    //aparcamientos.length
    for(let i=0;i<10;i++){
        contador++;
        let id = "mapa"+contador;

        let lat =  aparcamientos[i].geometry.coordinates[1];
        let lng =  aparcamientos[i].geometry.coordinates[0];

        // lo muestro si coincide
        let valor = this.value;
        
        if (aparcamientos[i].title.includes(valor)) {
            var nodo = nuevoElemento(aparcamientos[i],id);
            mostrar_mapa(lat, lng, id, aparcamientos[i].title);
            divPadre.appendChild(nodo);
        }

    }
}
// usamos templates string
function nuevoElemento(aparcamientos,id) {
    var html = `<div class="shadow-lg rounded card container-fluid py-3 text-center mt-3" style="width: 18rem;">
                    <div id=${id} style="width: 200; height: 250px;">
                    </div>
                    <div class="card-body  text-center p-4">
                        <h5 class="card-title"><i class="bi bi-geo-fill" style="font-size: 1.5rem;"></i>${aparcamientos.title}</h5>
                        <p class="card-text"><i class="bi bi-bicycle" style="font-size: 1.5rem;"></i> Plazas: ${aparcamientos.plazas}</p>
                        <p class="card-text"><i class="bi bi-check-circle" style="font-size: 1.5rem;"></i> Disponibles: ${aparcamientos.anclajes}</p>
                    </div>
                </div>`;
    return htmlToElement(html);
}

function htmlToElement(html) {
    var template = document.createElement("template");
    html = html.trim(); // Never return a text node of whitespace as the result 
    template.innerHTML = html;
    return template.content.firstChild;
}
